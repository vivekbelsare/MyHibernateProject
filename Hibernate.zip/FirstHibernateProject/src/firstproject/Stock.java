package firstproject;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity // this will map entity class with database

public class Stock {
@Id
	private int stockid;
	private String stockname;
	private int stockprice;
	private String mktcap;
	public Stock(){
		super();		
	}

	public Stock(int stockid, String stockname, int stockprice, String mktcap) {
		super();
		this.stockid = stockid;
		this.stockname = stockname;
		this.stockprice = stockprice;
		this.mktcap = mktcap;
	}
	public int getStockid() {
		return stockid;
	}
	public void setStockid(int stockid) {
		this.stockid = stockid;
	}
	public String getStockname() {
		return stockname;
	}
	public void setStockname(String stockname) {
		this.stockname = stockname;
	}
	public int getStockprice() {
		return stockprice;
	}
	public void setStockprice(int stockprice) {
		this.stockprice = stockprice;
	}
	public String getMktcap() {
		return mktcap;
	}
	public void setMktcap(String mktcap) {
		this.mktcap = mktcap;
	}
	@Override
	public String toString() {
		return "Stock [stockid=" + stockid + ", stockname=" + stockname + ", stockprice=" + stockprice
				+ ", mktcap=" + mktcap + "]";
	}
	

}
