package firstproject;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
//for loading the data
public class StockClientSelect {
	public static void main(String[] args) {
		Configuration cfg= new Configuration();
		cfg.configure(); 
		cfg.addAnnotatedClass(Stock.class);
		SessionFactory factory= cfg.buildSessionFactory(); //Sessionfactory is interface
		Session session =factory.openSession();// connection
		Stock  stockdetails =session.load(Stock.class, 2); // this method will load the data
		System.out.println(stockdetails );
	}

}
