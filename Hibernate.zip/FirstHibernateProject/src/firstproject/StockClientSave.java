package firstproject;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StockClientSave {
	public static void main(String[] args) {
		Configuration cfg= new Configuration();
		cfg.configure(); 
		cfg.addAnnotatedClass(Stock.class);
		SessionFactory factory= cfg.buildSessionFactory(); //Sessionfactory is interface
		Session session =factory.openSession();// connection
	Transaction	transaction =session.beginTransaction();
	Stock stock= new Stock(4,"Wipro",379, "2.08LCr");
	session.save(stock);
	transaction.commit();
	}


}
