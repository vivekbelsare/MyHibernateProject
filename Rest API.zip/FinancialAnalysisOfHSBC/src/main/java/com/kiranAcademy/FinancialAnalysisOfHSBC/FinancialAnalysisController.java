package com.kiranAcademy.FinancialAnalysisOfHSBC;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FinancialAnalysisController {
	@RequestMapping ("Revenue")
		String currentYearRevenue(){
			return " financial year 2022 HSBC Revenue is $644 million";
	}
	@RequestMapping ("CompanyDetails")
	ArrayList<String> revenueDetails(){
		ArrayList<String>listRevenue=new ArrayList<String>();
		listRevenue.add("Company Name:HSBC");
		listRevenue.add("Headquarters: London, United Kingdom");
		listRevenue.add(" Market Capital :92.85 billion");
		listRevenue.add("Operates in: 63 countries");
		
		
		return listRevenue;
		
	}
	
	}

