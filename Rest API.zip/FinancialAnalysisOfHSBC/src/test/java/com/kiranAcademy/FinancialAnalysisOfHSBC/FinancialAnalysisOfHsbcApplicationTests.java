package com.kiranAcademy.FinancialAnalysisOfHSBC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinancialAnalysisOfHsbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
